from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, RadioField, EmailField, DateField, SelectField, SubmitField
from wtforms.validators import DataRequired, equal_to, length, Email


class RegisterForm(FlaskForm):
    username = StringField("Enter Username",
                       validators=[DataRequired(message="Username is required"),
                                       length(min=8, max=64, message="Username must be between 8 and 32 characters")])

    email = EmailField("Enter Email", validators=[DataRequired(message="Email is required"),
                                                  Email(message="Enter a valid email address")])

    password = PasswordField("Create Password", validators=[DataRequired(message="Password is required"), length(min=8, max=64,
                                                                                   message="Password length must be between 8 and 64 characters")])
    repeat_password = PasswordField("Repeat Password", validators=[
        DataRequired(message="Please confirm your password"), equal_to('password', message="Passwords must match")])

    birthday = DateField("Birthday", validators=[DataRequired(message="Birthday is required")])

    submit = SubmitField("Create Account")

class OrderForm(FlaskForm):
    full_name = StringField("Full Name", validators=[DataRequired()])
    product = SelectField("Product", choices=[])
    submit = SubmitField("Order")