from flask import Flask, render_template

from forms import RegisterForm, OrderForm

app = Flask(__name__)

app.config["SECRET_KEY"] = "qweqwrweterfaszdhdfrc"
profiles = []


@app.route('/')
def home():
    return render_template("Index.html", active='home')

@app.route('/products')
def products():
    return render_template("Products.html", active='products', products=products_list)

@app.route('/register', methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = {
            "username": form.username.data,
            "password": form.password.data,
            "email": form.email.data,
            "birthday": str(form.birthday.data),
        }
        profiles.append(user)
        print("\n--- New Registration ---")
        print(f"Username: {user['username']}")
        print(f"Email: {user['email']}")
        print(f"Birthday: {user['birthday']}")
        print(f"Password: {user['password']}")
        print(f"Total profiles: {len(profiles)}")
    return render_template("Register.html", form=form)

orders = []

@app.route('/order', methods=["GET", "POST"])
def order():
    form = OrderForm()
    form.product.choices = [(p["id"], p["name"]) for p in products_list]
    if form.validate_on_submit():
        orders.append({"name": form.full_name.data, "product": form.product.data})
        print(orders)
    return render_template("Order.html", form=form)




@app.route('/product/<product_id>')
def product_detail(product_id):
    selected_product = None
    for product in products_list:
        if product["id"] == product_id:
            selected_product = product
    return render_template("HomeworkDetails.html", product=selected_product)

@app.route('/login')
def login():
    return render_template("Login.html")

products_list = [
    {
        "id": "AJAZZ-AK820-MAX",
        "name": "AJAZZ AK820 MAX",
        "image": "keyboard2.jpg",
        "description": "Premium TKL mechanical keyboard with a built-in display, RGB lighting, and smooth magnetic switches. Perfect for enthusiasts who want performance and style",
        "price": "200 GEL"
    },
    {
        "id": "K-60",
        "name": "K-60",
        "image": "https://www.destructoid.com/wp-content/uploads/2022/02/txcrxg8uakp51-scaled.jpg",
        "description": "Our flagship magnetic switch keyboard with full RGB. Ultra-fast actuation and a satisfying typing feel for both gaming and everyday use",
        "price": "150 GEL"
    },
    {
        "id": "Razer Huntsman V3 Pro",
        "name": "Razer Huntsman V3 Pro",
        "image": "https://i.rtings.com/assets/pages/k02mT58d/best-razer-keyboards-2-20250502-medium.jpg?format=auto",
        "description": "Razer's top-tier analog optical keyboard with per-key precision and customizable actuation points. Built for competitive gaming at the highest level",
        "price": "200 GEL"
    },
    {
        "id": "AULA F75 Pro Wireless",
        "name": "AULA F75 Pro Wireless",
        "image": "https://m.media-amazon.com/images/I/61MC8BK0w0L._AC_SL1500_.jpg",
        "description": "Compact 75% wireless keyboard with tri-mode connectivity (Bluetooth, 2.4GHz, USB). Great battery life and a clean, minimal design",
        "price": "200 GEL"
    }
]









app.run(port=5001, debug=True)
